@extends('user.layouts.master')

@section('content')
    <div class="row">
        <div class=" col-6 offset-3">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="">
                            <div class=" mb-3">
                                <a href="{{ route('user#home') }}" class=" text-dark text-decoration-none">
                                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                                </a>
                            </div>
                            @if ('session'('sendSuccess'))
                                <div class="col-6 offset-6">
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <i class="fa-solid fa-circle-check mr-2"></i> {{ session('sendSuccess') }}
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                </div>
                            @endif
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-title">
                                        <h3 class="text-center title-2">Contact</h3>
                                    </div>
                                    <hr>

                                    <form action="{{ route('user#contactUpdate') }}" method="post" novalidate="novalidate">
                                        @csrf
                                        <div class="form-group">
                                            <label class="control-label mb-1">Name</label>
                                            <input id="cc-pament" name="name" type="text" value="{{ old('email', Auth::user()->name) }}" class="form-control @error('name') is-invalid @enderror" aria-required="true" aria-invalid="false" placeholder="Enter Name...">
                                            @error('name')
                                                <div class=" invalid-feedback">
                                                   {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Email</label>
                                            <input id="cc-pament" name="email" type="email" value="{{ old('email', Auth::user()->email) }}" class="form-control @error('email') is-invalid @enderror" aria-required="true" aria-invalid="false" placeholder="Enter Email...">
                                            @error('email')
                                                <div class=" invalid-feedback">
                                                   {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Message</label>
                                            <textarea name="message" id="" cols="30" rows="10" class=" form-control @error('message') is-invalid @enderror" placeholder="Enter Message..."></textarea>
                                            @error('message')
                                                <div class=" invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>

                                        <div>
                                            <button id="payment-button" type="submit" class="btn btn-lg bg-primary btn-block text-white">
                                                <i class="fa-solid fa-paper-plane mr-2"></i>
                                                <span id="payment-button-amount">Send</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
