@extends('admin.layouts.master')

@section('title','Contact List Page')

@section('content')
    <div class="row">
        <div class=" col-6 offset-3">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="">
                            <div class=" mb-3">
                                <a href="{{ route('admin#contactList') }}" class=" text-dark text-decoration-none">
                                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                                </a>
                            </div>
                            @if ('session'('sendSuccess'))
                                <div class="col-8 offset-4">
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <i class="fa-solid fa-circle-check mr-2"></i> {{ session('sendSuccess') }}
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                </div>
                            @endif
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-title">
                                        <h3 class="text-center title-2">Contact Edit Page</h3>
                                    </div>
                                    <hr>

                                    <form action="{{ route('admin#contactUpdate') }}" method="post" novalidate="novalidate">
                                        @csrf
                                        <input type="hidden" name="contact_id" value="{{$contact->id}}">
                                        <div class="form-group">
                                            <label class="control-label mb-1">Name</label>
                                            <input id="cc-pament" name="name" type="text" value="{{ old('name', $contact->name) }}" class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Name..." disabled>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Email</label>
                                            <input id="cc-pament" name="email" type="email" value="{{ old('email', $contact->email) }}" class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Email..." disabled>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Message</label>
                                            <textarea name="message" id="" cols="30" rows="10" class=" form-control @error('message') is-invalid @enderror" placeholder="Enter Message...">{{ old('message',$contact->message) }}</textarea>
                                            @error('message')
                                                <div class=" invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>

                                        <div>
                                            <button id="payment-button" type="submit" class="btn btn-lg bg-primary btn-block text-white">
                                                <i class="fa-solid fa-paper-plane mr-2"></i>
                                                <span id="payment-button-amount">Send</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
