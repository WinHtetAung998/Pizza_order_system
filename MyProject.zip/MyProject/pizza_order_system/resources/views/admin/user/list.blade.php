@extends('admin.layouts.master')

@section('title','User List Page')

@section('content')
<!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="col-md-12">
                <div class=" my-3">
                    <h3>Total - {{ $users->total() }}</h3>
                </div>
                @if ('session'('deleteSuccess'))
                <div class="col-4 offset-8">
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-circle-xmark me-2"> </i> {{ session('deleteSuccess') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
            @endif
            @if ('session'('updateSuccess'))
                <div class="col-4 offset-8">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-check mr-2"></i> {{ session('updateSuccess') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
            @endif

            <!-- DATA TABLE -->
               <div class="table-responsive table-responsive-data2">
                <table class="table table-data2 text-center">
                    <thead>
                        <tr class=" tr-shadow">
                            <th>Image</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th class="col-2">Role</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $user)
                            <tr class="tr-shadow">
                                <input type="hidden" class="userId" value="{{ $user->id }}">
                                <td class="col-2">
                                    @if ($user->image == null)
                                       @if ($user->gender == 'male')
                                         <img src="{{ asset('image/default_male.jpg') }}" class=" img-thumbnail shadow-sm">
                                       @else
                                         <img src="{{ asset('image/default_female.jpg') }}" class=" img-thumbnail shadow-sm">
                                       @endif
                                    @else
                                    <img src="{{ asset('storage/'.$user->image) }}" class=" img-thumbnail shadow-sm">
                                    @endif
                                </td>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->gender }}</td>
                                <td>{{ $user->phone }}</td>
                                <td>{{ $user->address }}</td>
                                <td>
                                    <div class=" table-data-feature">
                                           <select name="" id="" class=" form-control roleChange">
                                                <option value="admin" class=" text-center" @if ($user->role == 'admin') selected @endif>Admin</option>
                                                <option value="user" class=" text-center" @if ($user->role == 'user') selected @endif>User</option>
                                           </select>
                                    </div>
                                </td>
                                <td>
                                    <div class=" table-data-feature">
                                        <a href="{{ route('admin#userAccountEdit',$user->id) }}">
                                            <button class="item me-1" data-toggle="tooltip" data-placement="top" title="Edit">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </button>
                                        </a>
                                        <a href="{{ route('admin#userAccountDelete',$user->id )}}" class=" ml-1">
                                            <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="mt-3">
                    {{ $users->links() }}
                </div>
            </div>
                <!-- END DATA TABLE -->
            </div>
        </div>
    </div>
</div>
<!-- END MAIN CONTENT-->
@endsection

@section('scriptSection')
<script>
    $(document).ready(function(){

      $('.roleChange').change(function(){

            $role = $(this).val();
            $parentNode = $(this).parents("tr");
            $userId = $parentNode.find('.userId').val();

            $data = {
                'role' : $role ,
                'userId' : $userId
            }

            $.ajax({
            type: 'get',
            url: '/user/ajax/role/change',
            data: $data ,
            dataType: 'json',
            });
            window.location.href = "http://localhost:8000/user/list";
        });

    });
</script>
@endsection
