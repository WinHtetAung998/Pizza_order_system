@extends('admin.layouts.master')

@section('title','Admin List Page')

@section('content')
<!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="col-md-12">
               @if ('session'('deleteSuccess'))
                    <div class="col-4 offset-8">
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <i class="fa-solid fa-circle-xmark me-2"> </i> {{ session('deleteSuccess') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    </div>
                @endif

                <div class=" my-3">
                    <h3>Total - {{ $admin->total() }}</h3>
                </div>

              <!-- DATA TABLE -->
               <div class="table-responsive table-responsive-data2">
                <table class="table table-data2 text-center">
                    <thead>
                        <tr class=" tr-shadow">
                            <th>Image</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th class="col-2"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($admin as $a)
                            <tr class="tr-shadow">
                                <input type="hidden" class="userId" value="{{ $a->id }}">
                                <td class="col-2">
                                    @if ($a->image == null)
                                       @if ($a->gender == 'male')
                                         <img src="{{ asset('image/default_male.jpg') }}" class=" img-thumbnail shadow-sm">
                                       @else
                                         <img src="{{ asset('image/default_female.jpg') }}" class=" img-thumbnail shadow-sm">
                                       @endif
                                    @else
                                    <img src="{{ asset('storage/'.$a->image) }}" class=" img-thumbnail shadow-sm">
                                    @endif
                                </td>
                                <td>{{ $a->name }}</td>
                                <td>{{ $a->email }}</td>
                                <td>{{ $a->gender }}</td>
                                <td>{{ $a->phone }}</td>
                                <td>{{ $a->address }}</td>
                                <td class=" col-3">
                                    <div class=" table-data-feature">
                                        @if (Auth::user()->id == $a->id)
                                        @else
                                           <select name="" id="" class=" form-control roleChange">
                                                <option value="admin" class=" text-center" @if ($a->role == 'admin') selected @endif>Admin</option>
                                                <option value="user" class=" text-center" @if ($a->role == 'user') selected @endif>User</option>
                                           </select>
                                           <a href="{{ route('admin#delete',$a->id) }}" class=" ml-3">
                                            <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                  <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                           </a>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="mt-3">
                    {{ $admin->links() }}
                </div>
            </div>
                <!-- END DATA TABLE -->
            </div>
        </div>
    </div>
</div>
<!-- END MAIN CONTENT-->
@endsection

@section('scriptSection')
<script>
    $(document).ready(function(){

      $('.roleChange').change(function(){

            $role = $(this).val();
            $parentNode = $(this).parents("tr");
            $userId = $parentNode.find('.userId').val();

            $data = {
                'role' : $role ,
                'userId' : $userId
            }

            $.ajax({
            type: 'get',
            url: '/admin/ajax/role/change',
            data: $data ,
            dataType: 'json',
            });
            window.location.href = "http://localhost:8000/admin/list";
        });

    });
</script>
@endsection
