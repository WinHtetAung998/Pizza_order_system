<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ContactController extends Controller
{
     // direct user list page
     public function contactList(){
        $contacts = Contact::orderBy('created_at','desc')->paginate(6);
    return view('admin.contact.list',compact('contacts'));
    }

    // delete user account
    public function contactDelete($id){
        Contact::where('id',$id)->delete();
        return back()->with(['deleteSuccess' => 'Contact Delete...']);
    }

    // direct contact edit page
    public function contactEditPage($id){
        $contact = Contact::where('id',$id)->first();
        return view('admin.contact.edit',compact('contact'));
    }

    // update contact
    public function contactUpdate(Request $request){
        Validator::make($request->all(),[
            'message' => 'required|min:6'
        ])->validate();
        Contact::where('id',$request->contact_id)->update([
            'message' => $request->message
        ]);
        return back()->with(['sendSuccess' => 'Contact with User. Success...']);
    }
}
