<?php $__env->startSection('title','Contact List Page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class=" col-6 offset-3">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="">
                            <div class=" mb-3">
                                <a href="<?php echo e(route('admin#contactList')); ?>" class=" text-dark text-decoration-none">
                                    <i class="fa-solid fa-arrow-left me-1"></i> Back
                                </a>
                            </div>
                            <?php if('session'('sendSuccess')): ?>
                                <div class="col-8 offset-4">
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <i class="fa-solid fa-circle-check mr-2"></i> <?php echo e(session('sendSuccess')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-title">
                                        <h3 class="text-center title-2">Contact Edit Page</h3>
                                    </div>
                                    <hr>

                                    <form action="<?php echo e(route('admin#contactUpdate')); ?>" method="post" novalidate="novalidate">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="contact_id" value="<?php echo e($contact->id); ?>">
                                        <div class="form-group">
                                            <label class="control-label mb-1">Name</label>
                                            <input id="cc-pament" name="name" type="text" value="<?php echo e(old('name', $contact->name)); ?>" class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Name..." disabled>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Email</label>
                                            <input id="cc-pament" name="email" type="email" value="<?php echo e(old('email', $contact->email)); ?>" class="form-control" aria-required="true" aria-invalid="false" placeholder="Enter Email..." disabled>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label mb-1">Message</label>
                                            <textarea name="message" id="" cols="30" rows="10" class=" form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter Message..."><?php echo e(old('message',$contact->message)); ?></textarea>
                                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class=" invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div>
                                            <button id="payment-button" type="submit" class="btn btn-lg bg-primary btn-block text-white">
                                                <i class="fa-solid fa-paper-plane mr-2"></i>
                                                <span id="payment-button-amount">Send</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\MyProject\pizza_order_system\resources\views/admin/contact/edit.blade.php ENDPATH**/ ?>