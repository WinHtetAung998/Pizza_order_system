<?php $__env->startSection('title','Order List Page'); ?>

<?php $__env->startSection('content'); ?>
<!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="col-md-12">
                <!-- DATA TABLE -->
               <div class="table-responsive table-responsive-data2">
                  <a href="<?php echo e(route('admin#orderList')); ?>" class=" text-dark"><i class="fa-solid fa-arrow-left-long"></i> Back</a>

                <div class="card mt-4 row col-5">
                    <div class="card-body">
                        <div class=" mb-3 border-bottom">
                            <h3><i class="fa-solid fa-clipboard mr-3"></i> Order Info</h3>
                            <small class=" text-warning mt-3"><i class="fa-solid fa-triangle-exclamation"></i>Include Delivery Charges</small>
                        </div>
                        <div class="row mb-3">
                            <div class="col"> <i class="fa-solid fa-user mr-3"></i> Customer Name</div>
                            <div class="col"> <?php echo e(strtoupper($orderList[0]->user_name)); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col"> <i class="fa-solid fa-envelope mr-3"></i> Customer Email</div>
                            <div class="col"> <?php echo e($orderList[0]->user_email); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col"> <i class="fa-solid fa-barcode mr-3"></i> Order Code</div>
                            <div class="col"> <?php echo e($orderList[0]->order_code); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col"> <i class="fa-regular fa-clock mr-3"></i> Order Date</div>
                            <div class="col"> <?php echo e($orderList[0]->created_at->format('F-j-Y')); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col"> <i class="fa-solid fa-money-bill-wave mr-3"></i>Total</div>
                            <div class="col"> <?php echo e($order->total_price); ?> kyats</div>
                        </div>
                    </div>
                  </div>
                <table class="table table-data2 text-center">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Order ID</th>
                            <th>Product Image</th>
                            <th>Product Name</th>
                            <th>Order Date</th>
                            <th>Qty</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody id="dataList">
                        <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow">
                            <td></td>
                            <td><?php echo e($o->id); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/'.$o->product_image)); ?>" style="width: 100px;" class=" img-thumbnail shadow-sm" alt="">
                            </td>
                            <td><?php echo e($o->product_name); ?></td>
                            <td><?php echo e($o->created_at->format('F-j-Y')); ?></td>
                            <td><?php echo e($o->qty); ?></td>
                            <td><?php echo e($o->total); ?> kyats</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
                <!-- END DATA TABLE -->
            </div>
        </div>
    </div>
</div>
<!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\MyProject\pizza_order_system\resources\views/admin/order/productList.blade.php ENDPATH**/ ?>