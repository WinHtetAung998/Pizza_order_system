<?php $__env->startSection('title','User List Page'); ?>

<?php $__env->startSection('content'); ?>
<!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="col-md-12">
                <div class=" my-3">
                    <h3>Total - <?php echo e($users->total()); ?></h3>
                </div>
                <?php if('session'('deleteSuccess')): ?>
                <div class="col-4 offset-8">
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-circle-xmark me-2"> </i> <?php echo e(session('deleteSuccess')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
            <?php endif; ?>
            <?php if('session'('updateSuccess')): ?>
                <div class="col-4 offset-8">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-check mr-2"></i> <?php echo e(session('updateSuccess')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
            <?php endif; ?>

            <!-- DATA TABLE -->
               <div class="table-responsive table-responsive-data2">
                <table class="table table-data2 text-center">
                    <thead>
                        <tr class=" tr-shadow">
                            <th>Image</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th class="col-2">Role</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="tr-shadow">
                                <input type="hidden" class="userId" value="<?php echo e($user->id); ?>">
                                <td class="col-2">
                                    <?php if($user->image == null): ?>
                                       <?php if($user->gender == 'male'): ?>
                                         <img src="<?php echo e(asset('image/default_male.jpg')); ?>" class=" img-thumbnail shadow-sm">
                                       <?php else: ?>
                                         <img src="<?php echo e(asset('image/default_female.jpg')); ?>" class=" img-thumbnail shadow-sm">
                                       <?php endif; ?>
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('storage/'.$user->image)); ?>" class=" img-thumbnail shadow-sm">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->gender); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->address); ?></td>
                                <td>
                                    <div class=" table-data-feature">
                                           <select name="" id="" class=" form-control roleChange">
                                                <option value="admin" class=" text-center" <?php if($user->role == 'admin'): ?> selected <?php endif; ?>>Admin</option>
                                                <option value="user" class=" text-center" <?php if($user->role == 'user'): ?> selected <?php endif; ?>>User</option>
                                           </select>
                                    </div>
                                </td>
                                <td>
                                    <div class=" table-data-feature">
                                        <a href="<?php echo e(route('admin#userAccountEdit',$user->id)); ?>">
                                            <button class="item me-1" data-toggle="tooltip" data-placement="top" title="Edit">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(route('admin#userAccountDelete',$user->id )); ?>" class=" ml-1">
                                            <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="mt-3">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
                <!-- END DATA TABLE -->
            </div>
        </div>
    </div>
</div>
<!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptSection'); ?>
<script>
    $(document).ready(function(){

      $('.roleChange').change(function(){

            $role = $(this).val();
            $parentNode = $(this).parents("tr");
            $userId = $parentNode.find('.userId').val();

            $data = {
                'role' : $role ,
                'userId' : $userId
            }

            $.ajax({
            type: 'get',
            url: '/user/ajax/role/change',
            data: $data ,
            dataType: 'json',
            });
            window.location.href = "http://localhost:8000/user/list";
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\MyProject\pizza_order_system\resources\views/admin/user/list.blade.php ENDPATH**/ ?>