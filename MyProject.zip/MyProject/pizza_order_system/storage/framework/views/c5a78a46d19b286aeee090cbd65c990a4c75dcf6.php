<?php $__env->startSection('content'); ?>
<!-- Shop Start -->
<div class="container-fluid">
    <div class="row px-xl-5">
        <!-- Shop Sidebar Start -->
        <div class="col-lg-3 col-md-4">
            <h5 class="section-title position-relative text-uppercase mb-3"><span class=" bg-white pr-3">Filter by categories</span></h5>
            <div class="bg-light p-4 mb-30">
                <form>
                    <div class=" d-flex align-items-center justify-content-between mb-3 bg-dark text-white px-3 py-1">
                        <label class="mt-2" for="price-all">Categories</label>
                        <span class="badge border border-warning font-weight-normal"><?php echo e(count($category)); ?></span>
                    </div>
                    <div class=" d-flex align-items-center mb-2 pt-1 btn-light">
                        <a href="<?php echo e(route('user#home')); ?>" class=" text-dark btn col text-left"><label >All</label></a>
                    </div>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class=" d-flex align-items-center mb-2 pt-1 btn-light">
                        <a href="<?php echo e(route('user#filter',$c->id)); ?>" class=" text-dark btn col text-left"><label ><?php echo e($c->name); ?></label></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </form>
            </div>
        </div>
        <!-- Shop Sidebar End -->

        <!-- Shop Product Start -->
        <div class="col-lg-9 col-md-8">
            <div class="row pb-3">
                <div class="col-12 pb-1">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <div>
                            <a href="<?php echo e(route('user#cartList')); ?>">
                                <button type="button" class="btn bg-dark text-white position-relative">
                                    <i class="fa-solid fa-cart-plus"></i>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        <?php echo e(count($cart)); ?>

                                    </span>
                                </button>
                            </a>
                            <a href="<?php echo e(route('user#history')); ?>" class="ms-3" >
                                <button type="button" class="btn bg-dark text-white position-relative">
                                    <i class="fa-solid fa-clock-rotate-left"></i> History
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        <?php echo e(count($history)); ?>

                                    </span>
                                </button>
                            </a>
                        </div>
                        <div class="ml-2">
                            <div class="btn-group">
                                <select name="sorting" class="form-control" id="sortingOption">
                                    <option value="">Choose One Option...</option>
                                    <option value="asc">Ascending</option>
                                    <option value="desc">Descending</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" id="dataList">
                    <?php if(count($pizza) != 0): ?>
                    <?php $__currentLoopData = $pizza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                            <div class="product-item bg-light mb-4" id="myForm">
                                <div class="product-img position-relative overflow-hidden">
                                    <img class="img-fluid w-100" style="height: 300px;" src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="">
                                    <div class="product-action">
                                        <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                        <a class="btn btn-outline-dark btn-square" href="<?php echo e(route('user#pizzaDetails',$p->id)); ?>"><i class="fa-solid fa-circle-info"></i></a>
                                    </div>
                                </div>
                                <div class="text-center py-4">
                                    <a class="h6 text-decoration-none text-truncate" href=""><?php echo e($p->name); ?></a>
                                    <div class="d-flex align-items-center justify-content-center mt-2">
                                        <h5><?php echo e($p->price); ?> kyats</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <p class=" text-center shadow-sm fs-1 col-6 offset-3 py-5">There is no pizza <i class="fa-solid fa-pizza-slice ml-3"></i></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Shop Product End -->
    </div>
</div>
<!-- Shop End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptSource'); ?>
<script>
        $(document).ready(function() {

        $('#sortingOption').change(function() {
            $eventOption = $('#sortingOption').val();

            if ($eventOption == 'asc') {
                $.ajax({
                    type: 'get',
                    url: '/user/ajax/pizza/list',
                    data: { 'status': 'asc' },
                    dataType: 'json',
                    success: function(response) {
                        $list = ``;
                        for ($i = 0; $i < response.length; $i++) {
                            $list += `
                            <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                <div class="product-item bg-light mb-4" id="myForm">
                                    <div class="product-img position-relative overflow-hidden">
                                        <img class="img-fluid w-100" style="height: 300px;" src="<?php echo e(asset('storage/${response[$i].image}')); ?>" alt="">
                                        <div class="product-action">
                                            <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                            <a class="btn btn-outline-dark btn-square" href=""><i class="fa-solid fa-circle-info"></i></a>
                                        </div>
                                    </div>
                                    <div class="text-center py-4">
                                        <a class="h6 text-decoration-none text-truncate" href="">${response[$i].name}</a>
                                        <div class="d-flex align-items-center justify-content-center mt-2">
                                            <h5>${response[$i].price} kyats</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                        }
                        $('#dataList').html($list);
                    }
                });
            } else if ($eventOption == 'desc') {
                $.ajax({
                    type: 'get',
                    url: '/user/ajax/pizza/list',
                    data: { 'status': 'desc' },
                    dataType: 'json',
                    success: function(response) {
                        $list = ``;
                        for ($i = 0; $i < response.length; $i++) {
                            $list += `
                            <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                <div class="product-item bg-light mb-4" id="myForm">
                                    <div class="product-img position-relative overflow-hidden">
                                        <img class="img-fluid w-100" style="height: 300px;" src="<?php echo e(asset('storage/${response[$i].image}')); ?>" alt="">
                                        <div class="product-action">
                                            <a class="btn btn-outline-dark btn-square" href=""><i class="fa fa-shopping-cart"></i></a>
                                            <a class="btn btn-outline-dark btn-square" href=""><i class="fa-solid fa-circle-info"></i></a>
                                        </div>
                                    </div>
                                    <div class="text-center py-4">
                                        <a class="h6 text-decoration-none text-truncate" href="">${response[$i].name}</a>
                                        <div class="d-flex align-items-center justify-content-center mt-2">
                                            <h5>${response[$i].price} kyats</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                        }
                        $('#dataList').html($list);
                    }
                });
            }
        });
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\MyProject\pizza_order_system\resources\views/user/main/home.blade.php ENDPATH**/ ?>